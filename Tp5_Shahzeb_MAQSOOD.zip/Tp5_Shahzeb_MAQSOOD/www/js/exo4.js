var family = {Maman:"Antoinette", Papa:"Thierry", Soeur:"Marie",Frere:"Pierre",Cousin1:"Charles",Cousin2:"Antoine"};

for(var id in family)
{
    alert(id + " : " + family[id]);
}