//Question 1 exo 1
var tab=[9,5,'Cergy']
alert("Ville : "+tab[2])

//Question 2 exo 1
var recetteGateau={Farine:"1 kg", Sucre : "0.6 kg", Oeuf : 30, Huile :"0.8 litre"}
alert("La quantité de sucre de l'objet recetteGateau est de : "+recetteGateau.Sucre)

//Question 3 exo 1
var PereDUBOIS={Nom:"DUBOIS",Prenom:"Paul",Enfants:["Marie","Christine","Jacques"],Loisir: Loisir={danse:"salsa"}}
alert("Le dernier enfant de Paul DUBOIS est s'appelle "+PereDUBOIS.Enfants[2])
alert("Leur loisir est la : "+PereDUBOIS.Loisir.danse)