function externe(nombre)
{
    var variable1 = nombre;
    
}