var nb1 = 10;
var nb2 = 20;

alert("nb1 : "+nb1)
alert("nb2 : "+nb2)

function somme(nb1,nb2)
{
    var somme=nb1+nb2;
    return somme;
}

var resultat = somme(nb1,nb2);
alert("Le résultat de la somme vaut : "+resultat)