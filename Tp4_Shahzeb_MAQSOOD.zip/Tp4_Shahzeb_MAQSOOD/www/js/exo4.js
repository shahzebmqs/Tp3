//Question 1

var tab=['s','a','l','u','t']
alert(tab[0])

//Question 2

var nb_tab = prompt("Saisir une taille du tableau");
var tab2=[]
var i=0

while(i<nb_tab)
{
var add_val = prompt("Saisir une valeur")
tab2.push(add_val)
i++
}

alert(tab2)
